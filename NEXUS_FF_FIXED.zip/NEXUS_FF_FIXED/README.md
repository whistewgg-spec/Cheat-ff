# NEXUS FF — Painel de Experimentação Android

## Estrutura
```
app/src/main/
├── cpp/           → Módulos nativos C++17 (NDK)
├── kotlin/        → UI Kotlin + JNI bridge
└── res/           → Layouts, cores, temas
```

## Pré-requisitos
- Android Studio Hedgehog (2023.1.1) ou superior
- NDK r25c ou superior
- CMake 3.22+
- JDK 17
- Dispositivo Android 8.0+ (API 26)

## Como compilar

### 1. Instalar NDK no Android Studio
```
File → Settings → Appearance & Behavior
  → System Settings → Android SDK → SDK Tools
  → ☑ NDK (Side by side) → Apply
```

### 2. Importar projeto
```
File → Open → selecione a pasta NEXUS_FF
```
Aguarde o Gradle sync.

### 3. Compilar APK debug
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
APK gerado em:
```
app/build/outputs/apk/debug/app-debug.apk
```

### 4. Compilar APK release (assinado)
```
Build → Generate Signed Bundle / APK
  → APK → Create new keystore
  → Preencha os dados → Release → Finish
```
APK gerado em:
```
app/build/outputs/apk/release/app-release.apk
```

## Instalar no dispositivo

### Via ADB
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Manual
1. Copie o APK para o dispositivo
2. Habilite "Fontes desconhecidas" nas configurações
3. Abra o APK e instale

## Permissões necessárias
- **Sobreposição de janelas** — solicitada automaticamente ao abrir o app
  - Configurações → Apps → NEXUS FF → Exibir sobre outros apps → Permitir

## Módulos nativos

| Módulo | Arquivo | Função |
|--------|---------|--------|
| Memory | `memory.cpp` | `process_vm_readv` + `/proc/pid/mem` |
| ESP | `esp.cpp` | Leitura de entidades, projeção W2S |
| Aimbot | `aimbot.cpp` | Busca de alvo por FOV, suavização |
| Recoil | `recoil.cpp` | Zera recoil/spread na arma ativa |

## Notas de build NDK

Os módulos nativos compilam para `arm64-v8a` e `armeabi-v7a`.
Offsets em `offsets.h` precisam ser re-derivados após updates do jogo:
1. Extraia `libil2cpp.so` do APK do jogo
2. Abra no IDA Pro / Ghidra
3. Busque as estruturas de Player, Health, Camera
4. Atualize os valores em `offsets.h`

## Estrutura de offsets
```
GWorld → PlayerArray[i] → Entity
                         ├─ +0x0C4 Health (float)
                         ├─ +0x0C8 HealthMax (float)
                         ├─ +0x148 TeamID (int)
                         ├─ +0x1A0 Position (Vector3)
                         └─ +0x730 BoneMatrix*
```
