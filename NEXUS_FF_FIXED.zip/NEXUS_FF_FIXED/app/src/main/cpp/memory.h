#pragma once
#include <cstdint>
#include <cstddef>
#include <string>

namespace Memory {

    // PID do processo alvo
    extern pid_t target_pid;
    // Base da libil2cpp.so no processo alvo
    extern uintptr_t il2cpp_base;

    // Inicializa: busca PID por nome de processo e mapeia base
    // nome_processo: "com.dts.freefiremax" ou "com.garena.msdk"
    bool Init(const std::string& nome_processo);

    // Lê T bytes do endereço addr no processo alvo
    // Usa process_vm_readv (não precisa de root em builds < Android 10 sem SELinux)
    // Fallback: /proc/pid/mem via pread
    template<typename T>
    T Read(uintptr_t addr);

    // Escreve T no endereço addr no processo alvo
    // Usa process_vm_writev
    template<typename T>
    bool Write(uintptr_t addr, T value);

    // Lê bloco de bytes
    bool ReadBuffer(uintptr_t addr, void* buf, size_t size);
    bool WriteBuffer(uintptr_t addr, const void* buf, size_t size);

    // Percorre pointer chain: base + offsets[0] → deref → + offsets[1] → ...
    uintptr_t WalkChain(uintptr_t base, const uintptr_t* offsets, size_t count);

    // Retorna base da lib pelo nome em /proc/pid/maps
    uintptr_t GetModuleBase(pid_t pid, const std::string& lib_name);

    bool IsValid();
}
