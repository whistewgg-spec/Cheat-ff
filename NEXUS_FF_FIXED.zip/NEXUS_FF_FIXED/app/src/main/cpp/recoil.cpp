// recoil.cpp — No Recoil e Crosshair helpers
#include "memory.h"
#include "offsets.h"
#include <android/log.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NexusRecoil", __VA_ARGS__)

namespace Recoil {
    static bool enabled = false;
    static float comp_x = 1.0f;
    static float comp_y = 1.0f;

    void SetEnabled(bool v) { enabled = v; }
    void SetCompensation(float x, float y) { comp_x = x; comp_y = y; }

    // Chamado no loop principal — zera recoil da arma ativa
    void Tick(uintptr_t weapon_addr) {
        if (!enabled || !weapon_addr) return;
        Memory::Write<float>(weapon_addr + offsets::WeaponRecoilX, 0.0f * comp_x);
        Memory::Write<float>(weapon_addr + offsets::WeaponRecoilY, 0.0f * comp_y);
        Memory::Write<float>(weapon_addr + offsets::WeaponSpread,  0.0f);
    }
}
