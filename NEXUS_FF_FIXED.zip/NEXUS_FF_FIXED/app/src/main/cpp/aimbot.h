#pragma once
#include "esp.h"

namespace Aimbot {
    struct Config {
        bool enabled         = false;
        bool aimlock         = false;
        float fov            = 90.0f;         // graus — raio de detecção
        float smoothness     = 5.0f;          // 1=instantâneo, 10=suave
        int   target_bone    = 7;             // 7=head, 5=chest
        bool  magic_bullet   = false;
        float headshot_chance= 0.75f;         // 0.0–1.0
        bool  headshot_100   = false;
        bool  no_recoil      = false;
        float recoil_x_comp  = 1.0f;
        float recoil_y_comp  = 1.0f;
        bool  target_tracking= false;
    };

    extern Config cfg;

    // Busca melhor alvo dentro do FOV
    // screen_cx/cy: centro da tela
    EntityInfo* FindBestTarget(float screen_cx, float screen_cy, int sw, int sh);

    // Aplica movimento de aim suave para o alvo
    void AimAt(const EntityInfo& target, float screen_cx, float screen_cy, int sw, int sh);

    // Zera recoil escrevendo valores no processo
    void SuppressRecoil(uintptr_t weapon_addr);

    // Magic bullet: força hitbox de cabeça na bala em voo
    void ApplyMagicBullet(uintptr_t weapon_addr);

    // Força ângulo de câmera para apontar ao osso alvo
    void SetCameraAngle(float yaw, float pitch);

    void SetEnabled(bool v);
    void SetAimlock(bool v);
}
