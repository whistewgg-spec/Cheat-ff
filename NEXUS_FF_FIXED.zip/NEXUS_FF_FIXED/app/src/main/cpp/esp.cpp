// esp.cpp — leitura de entidades e projeção de mundo→tela
#include "esp.h"
#include "memory.h"
#include "offsets.h"
#include <android/log.h>
#include <cmath>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NexusESP", __VA_ARGS__)

// Definição do método fora de qualquer namespace
Vector2 Matrix4x4::WorldToScreen(const Vector3& w, int sw, int sh) const {
    float clip_x = w.x * m[0][0] + w.y * m[1][0] + w.z * m[2][0] + m[3][0];
    float clip_y = w.x * m[0][1] + w.y * m[1][1] + w.z * m[2][1] + m[3][1];
    float clip_w = w.x * m[0][3] + w.y * m[1][3] + w.z * m[2][3] + m[3][3];
    if (clip_w <= 0.0f) return {-1, -1};
    float ndc_x = clip_x / clip_w;
    float ndc_y = clip_y / clip_w;
    return {
        (ndc_x + 1.0f) * 0.5f * (float)sw,
        (1.0f - ndc_y) * 0.5f * (float)sh
    };
}

namespace ESP {

    Config cfg;
    static std::vector<EntityInfo> entities;
    static Matrix4x4 view_matrix;

    static Vector3 ReadBonePosition(uintptr_t entity_base, int bone_id) {
        // BoneMatrix é array de Matrix4x4 (16 floats * bone_id)
        uintptr_t bone_addr = Memory::Read<uintptr_t>(entity_base + offsets::EntityBoneMatrix);
        if (!bone_addr) return {};
        // Cada osso: 4x4 matrix de float (64 bytes), posição em [3][0..2]
        uintptr_t entry = bone_addr + (uintptr_t)(bone_id * 48); // 48 bytes por osso em FF
        return Memory::Read<Vector3>(entry + 12);
    }

    void Update() {
        if (!cfg.enabled || !Memory::IsValid()) return;

        entities.clear();

        // Lê view matrix para W2S
        Memory::ReadBuffer(Memory::il2cpp_base + offsets::WorldToCamera,
                           &view_matrix, sizeof(view_matrix));

        // Lê array de players
        uintptr_t world = Memory::Read<uintptr_t>(Memory::il2cpp_base + offsets::GWorld);
        if (!world) return;
        uintptr_t player_arr = Memory::Read<uintptr_t>(world + offsets::PlayerArrayBase);
        int count            = Memory::Read<int>(world + offsets::PlayerArrayCount);
        if (count <= 0 || count > 32) return;

        for (int i = 0; i < count; i++) {
            uintptr_t entity = Memory::Read<uintptr_t>(player_arr + (uintptr_t)(i * 8));
            if (!entity) continue;

            EntityInfo info{};
            info.base_addr  = entity;
            info.health     = Memory::Read<float>(entity + offsets::EntityHealth);
            info.health_max = Memory::Read<float>(entity + offsets::EntityHealthMax);
            info.team_id    = Memory::Read<int>(entity + offsets::EntityTeamID);
            info.is_alive   = (info.health > 0.0f);
            info.position   = Memory::Read<Vector3>(entity + offsets::EntityPosition);

            if (!info.is_alive) continue;
            if (info.health_max <= 0.0f) info.health_max = 200.0f;

            // Ossos principais
            int bone_ids[] = {
                offsets::BONE_HEAD, offsets::BONE_NECK, offsets::BONE_CHEST,
                offsets::BONE_LSHOULDER, offsets::BONE_RSHOULDER,
                offsets::BONE_LKNEE, offsets::BONE_RKNEE,
                offsets::BONE_LFOOT, offsets::BONE_RFOOT
            };
            for (int b = 0; b < 9; b++)
                info.bones[b] = ReadBonePosition(entity, bone_ids[b]);

            entities.push_back(info);
        }
        LOGI("ESP: %zu entidades ativas", entities.size());
    }

    const std::vector<EntityInfo>& GetEntities() { return entities; }

    Vector2 BoneToScreen(const Vector3& bone, int sw, int sh) {
        return view_matrix.WorldToScreen(bone, sw, sh);
    }

    void SetEnabled(bool v) { cfg.enabled = v; }
}
