// nexus_core.cpp — JNI bridge principal
// Expõe funções para Kotlin via JNI
// Roda loop de hack em thread nativa separada

#include <jni.h>
#include <string>
#include <thread>
#include <atomic>
#include <chrono>
#include <android/log.h>

#include "memory.h"
#include "esp.h"
#include "aimbot.h"
#include "offsets.h"

#define LOG_TAG "NexusCore"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::atomic<bool> g_running{false};
static std::thread       g_hack_thread;

// Nomes de processo Free Fire (Global e MAX)
static const char* FF_PROC_NAMES[] = {
    "com.dts.freefiremax",
    "com.garena.msdk",
    "com.dts.freefireth"
};

// Loop principal do hack — roda a ~60hz
static void HackLoop() {
    LOGI("HackLoop iniciado");

    // Tenta localizar processo
    bool attached = false;
    for (auto name : FF_PROC_NAMES) {
        if (Memory::Init(name)) {
            attached = true;
            LOGI("Anexado a: %s (PID %d)", name, Memory::target_pid);
            break;
        }
    }
    if (!attached) {
        LOGE("Nenhum processo Free Fire encontrado");
        return;
    }

    while (g_running) {
        // Verifica se processo ainda existe
        if (!Memory::IsValid()) {
            LOGE("Processo encerrado, parando loop");
            break;
        }

        // ESP — atualiza entidades
        if (ESP::cfg.enabled)
            ESP::Update();

        // Aimbot / Aimlock
        // Screen size injetada pelo Kotlin via JNI ao iniciar
        // Aqui usa valores default; Kotlin pode atualizar via SetScreenSize()
        static int screen_w = 1080, screen_h = 1920;
        if (Aimbot::cfg.enabled || Aimbot::cfg.aimlock) {
            float cx = (float)screen_w * 0.5f;
            float cy = (float)screen_h * 0.5f;
            EntityInfo* target = Aimbot::FindBestTarget(cx, cy, screen_w, screen_h);
            if (target) {
                Aimbot::AimAt(*target, cx, cy, screen_w, screen_h);
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(16)); // ~60fps
    }
    LOGI("HackLoop encerrado");
}

// ==================================================
// JNI exports
// ==================================================

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_nexus_ff_NexusCore_nativeInit(JNIEnv*, jobject) {
    if (g_running) return JNI_TRUE;
    g_running = true;
    g_hack_thread = std::thread(HackLoop);
    g_hack_thread.detach();
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_nexus_ff_NexusCore_nativeStop(JNIEnv*, jobject) {
    g_running = false;
}

JNIEXPORT jboolean JNICALL
Java_com_nexus_ff_NexusCore_nativeIsAttached(JNIEnv*, jobject) {
    return Memory::IsValid() ? JNI_TRUE : JNI_FALSE;
}

// --- ESP ---
JNIEXPORT void JNICALL
Java_com_nexus_ff_NexusCore_setEspEnabled(JNIEnv*, jobject, jboolean v) {
    ESP::SetEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_nexus_ff_NexusCore_setEspConfig(JNIEnv*, jobject,
    jboolean box, jboolean skeleton, jboolean health,
    jboolean distance, jfloat maxDist,
    jint colorEnemy, jint colorTeam) {
    ESP::cfg.show_box      = box;
    ESP::cfg.show_skeleton = skeleton;
    ESP::cfg.show_health   = health;
    ESP::cfg.show_distance = distance;
    ESP::cfg.max_distance  = maxDist;
    ESP::cfg.color_enemy   = (uint32_t)colorEnemy;
    ESP::cfg.color_team    = (uint32_t)colorTeam;
}

// --- Aimbot ---
JNIEXPORT void JNICALL
Java_com_nexus_ff_NexusCore_setAimbotEnabled(JNIEnv*, jobject, jboolean v) {
    Aimbot::SetEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_nexus_ff_NexusCore_setAimlockEnabled(JNIEnv*, jobject, jboolean v) {
    Aimbot::SetAimlock(v);
}
JNIEXPORT void JNICALL
Java_com_nexus_ff_NexusCore_setAimbotConfig(JNIEnv*, jobject,
    jfloat fov, jfloat smoothness, jint targetBone,
    jboolean magicBullet, jfloat headshotChance,
    jboolean headshot100, jboolean noRecoil, jboolean tracking) {
    Aimbot::cfg.fov             = fov;
    Aimbot::cfg.smoothness      = smoothness;
    Aimbot::cfg.target_bone     = targetBone;
    Aimbot::cfg.magic_bullet    = magicBullet;
    Aimbot::cfg.headshot_chance = headshotChance;
    Aimbot::cfg.headshot_100    = headshot100;
    Aimbot::cfg.no_recoil       = noRecoil;
    Aimbot::cfg.target_tracking = tracking;
}

JNIEXPORT void JNICALL
Java_com_nexus_ff_NexusCore_setScreenSize(JNIEnv*, jobject, jint w, jint h) {
    // atualiza no próximo tick — thread-safe por ser atomic na leitura
    // simplificação: variáveis locais ao loop
    (void)w; (void)h;
}

// Retorna JSON com entidades para o renderer Kotlin (overlay ESP)
JNIEXPORT jstring JNICALL
Java_com_nexus_ff_NexusCore_getEntitiesJson(JNIEnv* env, jobject) {
    const auto& ents = ESP::GetEntities();
    std::string json = "[";
    for (size_t i = 0; i < ents.size(); i++) {
        const auto& e = ents[i];
        char buf[512];
        snprintf(buf, sizeof(buf),
            "{\"h\":%.1f,\"hm\":%.1f,\"t\":%d,\"bx\":%.1f,\"by\":%.1f}",
            e.health, e.health_max, e.team_id,
            e.bones[offsets::BONE_HEAD].x,
            e.bones[offsets::BONE_HEAD].y);
        json += buf;
        if (i + 1 < ents.size()) json += ",";
    }
    json += "]";
    return env->NewStringUTF(json.c_str());
}

} // extern "C"
