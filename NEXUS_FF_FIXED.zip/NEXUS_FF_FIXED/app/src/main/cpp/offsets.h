#pragma once
#include <cstdint>

// ============================================================
// NEXUS FF — Free Fire Offsets
// ATENÇÃO: offsets mudam a cada update do jogo.
// Re-derive com IDA/Ghidra em libil2cpp.so após cada patch.
// Build base: Free Fire MAX / Global ~1.106.x (arm64)
// ============================================================

namespace offsets {

    // libil2cpp.so — base calculada em runtime via /proc/pid/maps
    // GWorld → array de players ativos
    constexpr uintptr_t GWorld             = 0x08A3C120;  // re-derive
    constexpr uintptr_t WorldToCamera      = 0x08A1F400;  // re-derive

    // UCharacter offsets (a partir da base da entidade)
    constexpr uintptr_t EntityHealth       = 0x0C4;
    constexpr uintptr_t EntityHealthMax    = 0x0C8;
    constexpr uintptr_t EntityTeamID       = 0x148;
    constexpr uintptr_t EntityBoneMatrix   = 0x730;  // matriz de ossos (4x4 float)
    constexpr uintptr_t EntityPosition     = 0x1A0;  // Vector3
    constexpr uintptr_t EntityIsAlive      = 0x0B8;
    constexpr uintptr_t EntityName         = 0x280;

    // Player array
    constexpr uintptr_t PlayerArrayBase    = 0x50;
    constexpr uintptr_t PlayerArrayCount   = 0x58;

    // Camera
    constexpr uintptr_t CameraFOV          = 0x2FC;
    constexpr uintptr_t CameraYaw          = 0x2D0;
    constexpr uintptr_t CameraPitch        = 0x2D4;

    // Weapon
    constexpr uintptr_t WeaponRecoilX      = 0x1B0;
    constexpr uintptr_t WeaponRecoilY      = 0x1B4;
    constexpr uintptr_t WeaponSpread       = 0x1C0;
    constexpr uintptr_t BulletVelocity     = 0x1D8;

    // Bone IDs (índices na BoneMatrix)
    constexpr int BONE_HEAD    = 7;
    constexpr int BONE_NECK    = 6;
    constexpr int BONE_CHEST   = 5;
    constexpr int BONE_LSHOULDER = 11;
    constexpr int BONE_RSHOULDER = 8;
    constexpr int BONE_LKNEE   = 23;
    constexpr int BONE_RKNEE   = 19;
    constexpr int BONE_LFOOT   = 25;
    constexpr int BONE_RFOOT   = 21;
}
