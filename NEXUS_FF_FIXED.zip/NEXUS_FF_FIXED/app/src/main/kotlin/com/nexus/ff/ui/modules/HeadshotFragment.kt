package com.nexus.ff.ui.modules

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.nexus.ff.NexusCore
import com.nexus.ff.R

class HeadshotFragment : Fragment() {

    private var chance = 0.75f

    companion object {
        fun newInstance(c: Float) = HeadshotFragment().apply {
            arguments = Bundle().apply { putFloat("chance", c) }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        chance = arguments?.getFloat("chance") ?: 0.75f
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_generic_module, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        val sw = v.findViewById<Switch>(R.id.switchModuleMain)
        val tv = v.findViewById<TextView>(R.id.tvModuleTitle)
        tv.text = if (chance >= 1f) "HEADSHOT 100%" else "HEADSHOT 75%"

        sw.setOnCheckedChangeListener { _, en ->
            NexusCore.setAimbotConfig(
                90f, 5f, 7, false,
                if (en) chance else 0f,
                en && chance >= 1f,
                false, false
            )
        }
    }
}
