package com.nexus.ff

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.nexus.ff.databinding.ActivityMainBinding
import com.nexus.ff.ui.ModulePagerAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val OVERLAY_PERMISSION_REQ = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Mantém tela ligada
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setupTabs()
        setupControls()
        checkOverlayPermission()

        // Inicializa core nativo
        NexusCore.start(
            resources.displayMetrics.widthPixels,
            resources.displayMetrics.heightPixels
        )
    }

    private fun setupTabs() {
        val adapter = ModulePagerAdapter(this)
        binding.viewPager.adapter = adapter
        binding.viewPager.offscreenPageLimit = adapter.itemCount

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, pos ->
            tab.text = adapter.getPageTitle(pos)
        }.attach()
    }

    private fun setupControls() {
        // Botão de overlay flutuante
        binding.btnOverlay.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                val intent = Intent(this, FloatingOverlayService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    startForegroundService(intent)
                else
                    startService(intent)
                binding.btnOverlay.text = "OVERLAY ATIVO"
                binding.btnOverlay.setBackgroundColor(
                    ContextCompat.getColor(this, R.color.accent_red)
                )
            } else {
                requestOverlayPermission()
            }
        }

        // Status de conexão
        binding.btnRefresh.setOnClickListener {
            val attached = NexusCore.nativeIsAttached()
            binding.tvStatus.text = if (attached) "● CONECTADO" else "○ AGUARDANDO"
            binding.tvStatus.setTextColor(
                ContextCompat.getColor(this,
                    if (attached) R.color.accent_green else R.color.accent_red)
            )
            if (!attached) {
                NexusCore.start(
                    resources.displayMetrics.widthPixels,
                    resources.displayMetrics.heightPixels
                )
            }
        }
    }

    private fun checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this))
            requestOverlayPermission()
    }

    private fun requestOverlayPermission() {
        Toast.makeText(this, "Autorize sobreposição de janelas", Toast.LENGTH_LONG).show()
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivityForResult(intent, OVERLAY_PERMISSION_REQ)
    }

    override fun onDestroy() {
        super.onDestroy()
        NexusCore.nativeStop()
    }
}
