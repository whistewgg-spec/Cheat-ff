package com.nexus.ff

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.*
import android.view.*
import android.view.WindowManager.LayoutParams.*
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import com.nexus.ff.overlay.EspRenderer

class FloatingOverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var overlayRoot: FrameLayout
    private lateinit var espRenderer: EspRenderer
    private lateinit var floatingMenu: View
    private var menuVisible = true
    private val handler = Handler(Looper.getMainLooper())

    // Atualiza ESP a ~30fps
    private val updateRunnable = object : Runnable {
        override fun run() {
            espRenderer.invalidate()
            handler.postDelayed(this, 33)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(1, buildNotification())
        setupOverlay()
        handler.post(updateRunnable)
    }

    private fun setupOverlay() {
        // Params da janela raiz — cobre tudo, não recebe input (passthrough)
        val rootParams = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                TYPE_APPLICATION_OVERLAY else TYPE_SYSTEM_ALERT,
            FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCHABLE or FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        overlayRoot = FrameLayout(this)
        espRenderer = EspRenderer(this)
        overlayRoot.addView(espRenderer,
            FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        wm.addView(overlayRoot, rootParams)

        // Menu flutuante — recebe toque, pode ser arrastado
        setupFloatingMenu()
    }

    private fun setupFloatingMenu() {
        val menuParams = WindowManager.LayoutParams(
            300.dpToPx(), WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                TYPE_APPLICATION_OVERLAY else TYPE_SYSTEM_ALERT,
            FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20; y = 200
        }

        floatingMenu = LayoutInflater.from(this)
            .inflate(R.layout.overlay_menu, null)

        // Drag
        var initX = 0; var initY = 0; var lastX = 0; var lastY = 0
        floatingMenu.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = menuParams.x; initY = menuParams.y
                    lastX = event.rawX.toInt(); lastY = event.rawY.toInt()
                }
                MotionEvent.ACTION_MOVE -> {
                    menuParams.x = initX + event.rawX.toInt() - lastX
                    menuParams.y = initY + event.rawY.toInt() - lastY
                    wm.updateViewLayout(floatingMenu, menuParams)
                }
            }
            false
        }

        wm.addView(floatingMenu, menuParams)
        setupMenuButtons()
    }

    private fun setupMenuButtons() {
        // Toggle ESP
        floatingMenu.findViewById<android.widget.Switch>(R.id.switchEsp)
            ?.setOnCheckedChangeListener { _, v -> NexusCore.setEspEnabled(v) }

        // Toggle Aimbot
        floatingMenu.findViewById<android.widget.Switch>(R.id.switchAimbot)
            ?.setOnCheckedChangeListener { _, v -> NexusCore.setAimbotEnabled(v) }

        // Toggle Aimlock
        floatingMenu.findViewById<android.widget.Switch>(R.id.switchAimlock)
            ?.setOnCheckedChangeListener { _, v -> NexusCore.setAimlockEnabled(v) }

        // Toggle No Recoil
        floatingMenu.findViewById<android.widget.Switch>(R.id.switchNoRecoil)
            ?.setOnCheckedChangeListener { _, v ->
                NexusCore.setAimbotConfig(
                    90f, 5f, 7, false, 0.75f,
                    false, v, false
                )
            }

        // Minimizar
        floatingMenu.findViewById<android.widget.ImageButton>(R.id.btnMinimize)
            ?.setOnClickListener {
                val content = floatingMenu.findViewById<android.view.View>(R.id.menuContent)
                menuVisible = !menuVisible
                content?.visibility = if (menuVisible) View.VISIBLE else View.GONE
            }
    }

    private fun Int.dpToPx(): Int =
        (this * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                "nexus_overlay", "NEXUS Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Overlay ativo" }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, "nexus_overlay")
            .setContentTitle("NEXUS FF")
            .setContentText("Overlay ativo")
            .setSmallIcon(R.drawable.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateRunnable)
        runCatching { wm.removeView(overlayRoot) }
        runCatching { wm.removeView(floatingMenu) }
    }

    override fun onBind(intent: Intent?) = null
}
