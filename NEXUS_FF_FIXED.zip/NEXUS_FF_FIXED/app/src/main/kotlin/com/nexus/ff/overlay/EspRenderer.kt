package com.nexus.ff.overlay

import android.content.Context
import android.graphics.*
import android.view.View
import com.nexus.ff.NexusCore
import org.json.JSONArray

class EspRenderer(context: Context) : View(context) {

    private val paintBox = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED; style = Paint.Style.STROKE; strokeWidth = 2f
    }
    private val paintSkeleton = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 1.5f
    }
    private val paintHealth = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val paintText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 28f
        setShadowLayer(4f, 1f, 1f, Color.BLACK)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        try {
            val json = NexusCore.getEntitiesJson()
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val hp  = e.getDouble("h").toFloat()
                val hpm = e.getDouble("hm").toFloat()
                val team = e.getInt("t")

                // Cor por time
                paintBox.color = if (team == 0) Color.RED else Color.GREEN
                paintSkeleton.color = if (team == 0) Color.WHITE else Color.CYAN

                // Posição de cabeça na tela (simplificado — renderer completo
                // usa projeção do native; aqui usa coords normalizadas)
                val bx = e.getDouble("bx").toFloat()
                val by = e.getDouble("by").toFloat()
                if (bx <= 0 || by <= 0) continue

                // Box aproximada
                val boxH = 120f; val boxW = 60f
                canvas.drawRect(bx - boxW/2, by - boxH*0.1f,
                                bx + boxW/2, by + boxH, paintBox)

                // Barra de vida
                val barW = boxW
                val hpRatio = (hp / hpm).coerceIn(0f, 1f)
                paintHealth.color = Color.argb(200, 255, 0, 0)
                canvas.drawRect(bx - barW/2, by - 20f,
                                bx + barW/2, by - 10f, paintHealth)
                paintHealth.color = Color.argb(220,
                    (255 * (1 - hpRatio)).toInt(),
                    (255 * hpRatio).toInt(), 0)
                canvas.drawRect(bx - barW/2, by - 20f,
                                bx - barW/2 + barW * hpRatio, by - 10f, paintHealth)

                // HP text
                canvas.drawText("${hp.toInt()}/${hpm.toInt()}",
                    bx - 30f, by - 24f, paintText)
            }
        } catch (_: Exception) {}
    }
}
