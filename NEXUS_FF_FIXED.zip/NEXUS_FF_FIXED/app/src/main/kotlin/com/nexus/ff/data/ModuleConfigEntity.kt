package com.nexus.ff.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "module_configs")
data class ModuleConfigEntity(
    @PrimaryKey val moduleId: String,   // "esp", "aimbot", etc.
    val profileId: Int,
    val enabled: Boolean = false,
    val configJson: String = "{}"
)
