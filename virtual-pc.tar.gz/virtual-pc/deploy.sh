#!/bin/bash
# deploy.sh — cria o repo no GitHub e faz push
# uso: bash deploy.sh SEU_TOKEN NOME_DO_REPO
# ex:  bash deploy.sh ghp_xxx virtual-pc

TOKEN=$1
REPO_NAME=${2:-virtual-pc}

if [ -z "$TOKEN" ]; then
  echo "uso: bash deploy.sh SEU_TOKEN [nome-do-repo]"
  exit 1
fi

# pega username
USER=$(curl -s -H "Authorization: token $TOKEN" \
  https://api.github.com/user | grep '"login"' | head -1 | \
  sed 's/.*"login": "\(.*\)".*/\1/')

echo "[+] Usuário: $USER"
echo "[+] Criando repositório: $REPO_NAME"

# cria repo
curl -s -X POST \
  -H "Authorization: token $TOKEN" \
  -H "Content-Type: application/json" \
  https://api.github.com/user/repos \
  -d "{\"name\":\"$REPO_NAME\",\"private\":false,\"description\":\"PC virtual via GitHub Codespaces\"}" \
  | grep '"full_name"'

# init e push
cd "$(dirname "$0")"
git init
git add .
git commit -m "feat: virtual PC setup"
git branch -M main
git remote add origin "https://$TOKEN@github.com/$USER/$REPO_NAME.git"
git push -u origin main

echo ""
echo "✅ Repositório criado: https://github.com/$USER/$REPO_NAME"
echo ""
echo "Para criar o Codespace:"
echo "  https://github.com/$USER/$REPO_NAME/codespaces/new"
echo ""
echo "Ou via CLI:"
echo "  gh codespace create --repo $USER/$REPO_NAME --machine standardLinux32gb"
