# 🖥️ Virtual PC — GitHub Codespaces

PC virtual completo rodando no browser via GitHub Codespaces.  
Windows 10/11 ou Linux KDE — sem instalação, sem hardware.

---

## 🚀 Setup em 3 passos

### 1. Abre o Codespace
Clica em **Code → Codespaces → Create codespace on main**  
O setup roda automático (~2 min).

### 2. Configura senha (opcional)
```bash
cp .env.example .env
# edita WIN_USER e WIN_PASS no .env
```

### 3. Inicia o PC virtual

**Windows 10:**
```bash
make windows
# ou: docker compose -f windows.yml up -d
```
→ Aba **Ports** → porta `8006` → Abre no browser

**Linux KDE:**
```bash
make linux
# ou: docker compose -f linux.yml up -d
```
→ Aba **Ports** → porta `6080` → Abre no browser

---

## 📡 Portas

| Porta | Serviço |
|-------|---------|
| `8006` | Windows — noVNC web |
| `3389` | Windows — RDP nativo |
| `6080` | Linux — noVNC web |

---

## ⚙️ Configuração

Edita `windows.yml` para ajustar recursos:

```yaml
environment:
  VERSION: "11"      # Windows 10 ou 11
  RAM_SIZE: "8G"     # RAM alocada
  CPU_CORES: "4"     # Núcleos de CPU
  DISK_SIZE: "64G"   # Disco virtual
```

---

## ⏱️ Tempo de boot

| | Primeira vez | Reinicializações |
|-|-------------|-----------------|
| Windows | 5–10 min | 2–3 min |
| Linux KDE | 1–2 min | 30 seg |

---

## 🛠️ Comandos úteis

```bash
make windows        # inicia Windows
make linux          # inicia Linux
make stop           # para tudo
make logs-windows   # logs do Windows
make clean          # limpa Docker
```

---

## ⚠️ Limites do Codespace grátis

- **60 horas/mês** no plano free
- **32 GB** de storage por Codespace
- Para mais horas: github.com/settings/billing

---

Baseado em [dockurr/windows](https://github.com/dockurr/windows) e [linuxserver/webtop](https://github.com/linuxserver/docker-webtop).
